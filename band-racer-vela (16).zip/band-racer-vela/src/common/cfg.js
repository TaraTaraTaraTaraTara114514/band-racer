/*
 * 设置：操控方式、全屏、透明度、陀螺仪方向、按键布局。纯数据，不碰界面。
 */
export var CTL_NAMES = ['按键', '摇杆', '滑动', '陀螺仪'];
export var ALPHAS = [1, 0.75, 0.5, 0.25];
export var ALPHA_TXT = ['100%', '75%', '50%', '25%'];
export var TILT_NAMES = ['正常', '左右反', '上下反', '全反'];
// 陀螺仪：丝滑程度（越大越平滑、反应越慢）、换道角度、每多倾斜几度再滑一次
export var SMOOTH_F = [0.2, 0.4, 0.6, 0.75, 0.88];
export var ANGLES = [5, 8, 10, 15, 20, 25, 30, 40];
export var STEP_ANGLES = [5, 8, 10, 15, 20, 30];
export var ITEM_KEYS = ['up', 'down', 'left', 'right', 'jump', 'joy'];

var SCREEN_W = 192;
var SCREEN_H = 490;
var PAD_TOP = 340;   // 不全屏时，按键只能放在游戏下面这一块

function defLayout() {
  return {
    up: { x: 49, y: 345, s: 46 },
    left: { x: 1, y: 393, s: 46 },
    right: { x: 97, y: 393, s: 46 },
    down: { x: 49, y: 441, s: 46 },
    jump: { x: 145, y: 393, s: 46 },
    joy: { x: 10, y: 378, s: 92 }
  };
}

export function defaults() {
  return { ctl: 0, full: 0, alpha: 0, tilt: 0, smooth: 2, angle: 3, step: 2, shv: 0, shh: 0, lay: { n: defLayout(), f: defLayout() } };
}

export function minSize(key) { return key === 'joy' ? 50 : 24; }
export function maxSize(key) { return key === 'joy' ? 130 : 80; }

function num(v, d) {
  v = Number(v);
  return isFinite(v) ? Math.round(v) : d;
}
function lim(v, a, b) { return v < a ? a : (v > b ? b : v); }

// 把 item 限制在允许的范围里；全屏可以放到屏幕任何位置，不全屏只能放在下面的按键区
export function clampItem(key, it, full) {
  it.s = lim(num(it.s, 46), minSize(key), maxSize(key));
  it.x = lim(num(it.x, 0), 0, SCREEN_W - it.s);
  it.y = lim(num(it.y, PAD_TOP), full ? 0 : PAD_TOP, SCREEN_H - it.s);
  return it;
}

export function normalize(raw) {
  var c = defaults();
  if (!raw || typeof raw !== 'object') return c;
  c.ctl = lim(num(raw.ctl, 0), 0, 3);
  c.full = raw.full ? 1 : 0;
  c.alpha = lim(num(raw.alpha, 0), 0, ALPHAS.length - 1);
  c.tilt = lim(num(raw.tilt, 0), 0, 3);
  c.smooth = lim(num(raw.smooth, 2), 0, SMOOTH_F.length - 1);
  c.angle = lim(num(raw.angle, 3), 0, ANGLES.length - 1);
  c.step = lim(num(raw.step, 2), 0, STEP_ANGLES.length - 1);
  c.shv = raw.shv ? 1 : 0;
  c.shh = raw.shh ? 1 : 0;
  var sets = ['n', 'f'];
  for (var a = 0; a < 2; a++) {
    var src = raw.lay && raw.lay[sets[a]];
    for (var i = 0; i < ITEM_KEYS.length; i++) {
      var k = ITEM_KEYS[i];
      var it = c.lay[sets[a]][k];
      if (src && src[k]) {
        it.x = num(src[k].x, it.x);
        it.y = num(src[k].y, it.y);
        it.s = num(src[k].s, it.s);
      }
      clampItem(k, it, a === 1);
    }
  }
  return c;
}

export function parse(text) {
  try { return normalize(JSON.parse(text)); } catch (e) { return defaults(); }
}

// 界面要用的各种尺寸（一次算好，界面里直接引用）
export function derive(it) {
  var s = it.s;
  var ao = Math.round(s * 0.22);
  var q = Math.round(s * 0.48);
  var k = Math.round(s * 0.4);
  return {
    l: it.x, t: it.y, s: s,
    r: Math.round(s * 0.22),          // 圆角
    ao: ao, as: s - 2 * ao,           // 箭头图标的位置、大小
    q: q, jl: Math.round((s - q) / 2), jt: Math.round(s * 0.11),   // 跳跃键里的方框
    tt: Math.round(s * 0.63), fs: s < 40 ? 10 : 12,                // 跳跃键里的次数文字
    jr: Math.round(s / 2),            // 摇杆底盘圆角
    k: k, kc: Math.round((s - k) / 2) // 摇杆圆头大小、居中偏移
  };
}

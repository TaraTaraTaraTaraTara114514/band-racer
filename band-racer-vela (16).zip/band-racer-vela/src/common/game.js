/*
 * 手环赛车 - 纯游戏逻辑（不碰界面）。
 * 游戏区 192 x 340，y 向下增大。5 条赛道。
 * 页面每 50ms 调一次 tick()，再用 view() 取要显示的内容。
 */
var GAME_H = 340;
var LANES = 5;
var LANE_W = 26;
var ROAD_X = 4;
var MAX_CARS = 12;
var MAX_PARTS = 10;
var JUMP_T = 0.72;      // 跳跃滞空时间（秒）
var DODGE_SCORE = 1;    // 不跳、直接躲开一辆车的得分（设为 0 就只有跳过去才得分）
var SEDAN_COLORS = 7;   // 轿车颜色数量，sedan_0..6，没有红色
var KART_COLORS = 5;
var FAST_P = 0.05;         // 极速摩托车刷新概率
var MOTO_COLORS = 8;
var PW = 20;
var PH = 29;
var CORNER_R = 96;  // 屏幕上端圆角的半径；圆角到这里就结束，往下是完整宽度
var PY_MIN = CORNER_R + 15;   // 车能开到的最高位置：车头刚好在圆角尽头（车身半高约 14.5）
var PY_MAX = 312;
var BOTTOM_R = 96;   // 全屏时屏幕下端也是圆角，车最低开到圆角的尽头
var PARTICLE_COLORS = ['#fff6b0', '#ffd23a', '#ff9a2e', '#ff5a1f', '#e8262b', '#f4f8ff'];

var TYPES = {
  sedan: { w: 20, h: 29, hw: 7, hh: 12, mult: 1.0, score: 2 },
  kart:  { w: 17, h: 25, hw: 6, hh: 10, mult: 2.1, score: 4 },   // 卡丁车比轿车快得多
  truck: { w: 22, h: 47, hw: 9, hh: 21, mult: 0.85, score: 0 },
  moto:  { w: 16, h: 34, hw: 5, hh: 14, mult: 1.5, score: 3 },   // 摩托车：速度是轿车的 1.5 倍，会在赛道间乱窜，可以跳过
  fast:  { w: 18, h: 38, hw: 6, hh: 16, mult: 3.0, score: 10 }   // 极速摩托车（红）：速度是轿车的 3 倍，不变道，撞到别的车会爆炸，跳过 +10
};

// 四档难度（下标 0 困难 / 1 中等 / 2 简单 / 3 地狱；存储键按下标，所以新增的地狱放最后）。
//  lanes     一批最多出在几条赛道
//  laneCap   同一条赛道最多连出几辆（随级别变化）
//  batch     一批最多出几辆（99 = 不限）
//  truckFrom / kartFrom   到几级才开始出货车 / 卡丁车
//  truck / kart           出车概率 = a + 级别 * b
//  base / perLevel        车速 = (base + 级别 * perLevel) * 0.7，级别越高越快，perLevel 越小涨得越慢
//  moto = [起始级别, a, b]  摩托车出车概率 = a + 级别 * b（只有困难和地狱有）；同样从这个级别起，每辆车有 FAST_P 的概率是极速摩托
//  kartMult  卡丁车速度是轿车的几倍；gap 出车间隔倍数（越大出得越少）
var DIFFS = [
  { name: '困难', lanes: 4, batch: 99, truckFrom: 1, kartFrom: 1,
    laneCap: function (l) { return l >= 6 ? 3 : 2; },
    truck: [0.12, 0.012], kart: [0.2, 0.02], moto: [5, 0.06, 0.008], base: 130, perLevel: 14, kartMult: 2.1, gap: 1 },
  { name: '中等', lanes: 3, batch: 99, truckFrom: 1, kartFrom: 3,
    laneCap: function (l) { return l >= 8 ? 3 : 2; },
    truck: [0.12, 0.012], kart: [0.12, 0.012], base: 130, perLevel: 10, kartMult: 1.8, gap: 1.1 },
  { name: '简单', lanes: 2, batch: 2, truckFrom: 3, kartFrom: 5,
    laneCap: function (l) { return l >= 5 ? 2 : 1; },
    truck: [0.08, 0.01], kart: [0.04, 0.006], base: 120, perLevel: 7, kartMult: 1.5, gap: 1.25 },
  { name: '地狱', lanes: 4, batch: 99, truckFrom: 1, kartFrom: 1,
    laneCap: function (l) { return l >= 4 ? 3 : 2; },
    truck: [0.12, 0.012], kart: [0.18, 0.018], moto: [1, 0.08, 0.01], base: 145, perLevel: 17, kartMult: 2.3, gap: 0.85 }
];
var D = DIFFS[0];
var diffIndex = 0;

function cx(l) { return ROAD_X + l * LANE_W + LANE_W / 2; }
function rnd(a, b) { return a + Math.random() * (b - a); }
function ri(n) { return Math.floor(Math.random() * n); }
function rd(n) { return Math.round(n); }

var S = {
  state: 'ready', t: 0, score: 0, jumps: 1, best: 0,
  cars: [], parts: [], pops: [], scroll: 0, spawn: 0.8,
  bests: [0, 0, 0, 0],            // 四个难度各自的最高分；best 是当前难度的那个
  overT: 0, boom: null, dirty: true,
  slots: [], slotSrc: []          // 车辆图片的固定位置：一辆车从出现到消失一直用同一个位置，避免图片频繁重新加载
};
var P = { lane: 2, x: cx(2), y: 265, jumpT: -1 };
var keys = { up: false, down: false, left: false, right: false };
var hold = { left: 0, right: 0 };
var laneBuf = [[], [], [], [], []];   // 每条赛道的车，反复使用，不每帧新建数组
function byYDesc(a, b) { return b.y - a.y; }

// 画面里没东西的位置，藏在屏幕外。这些对象一次建好反复用，view() 每帧不用再新建。
// 每个位置各用自己的一个对象（不共用同一个），车辆位置的图片 src 一直保持，避免图片重新加载。
var HIDDEN_CARS = [], HIDDEN_PARTS = [], HIDDEN_POPS = [];
(function () {
  var i;
  for (i = 0; i < MAX_CARS; i++) HIDDEN_CARS.push({ src: '/common/sedan_0.png', l: -60, t: -80, w: 20, h: 29 });
  for (i = 0; i < MAX_PARTS; i++) HIDDEN_PARTS.push({ l: -30, t: -30, s: 2, c: '#ffd23a' });
  for (i = 0; i < 2; i++) HIDDEN_POPS.push({ l: -60, t: -60, txt: '' });
})();

// 游戏区高度：340（下面留给按键）或 490（全屏）。全屏时上下可移动范围更大。
function setArea(h) {
  GAME_H = h;
  PY_MAX = h > 340 ? h - BOTTOM_R - 15 : 312;
  if (P.y > PY_MAX) P.y = PY_MAX;
}

function lvl() { return Math.min(10, 1 + Math.floor(S.score / 10)); }
function spd() { return (D.base + lvl() * D.perLevel) * 0.7; }
function jumpZ() { return P.jumpT >= 0 ? Math.sin(Math.PI * P.jumpT / JUMP_T) : 0; }
function airborne() { return jumpZ() > 0.3; }

// 切换难度（0 困难 / 1 中等 / 2 简单 / 3 地狱），下一局开始生效
function setDifficulty(i) {
  if (i < 0 || i >= DIFFS.length) i = 0;
  S.bests[diffIndex] = S.best;   // 先把旧难度的最高分放好
  diffIndex = i;
  D = DIFFS[i];
  S.best = S.bests[i];
  S.dirty = true;
}

function reset() {
  S.state = 'play';
  S.score = 0; S.jumps = 1; S.cars = []; S.parts = []; S.pops = []; S.slots = []; S.slotSrc = [];
  S.spawn = 0.8; S.overT = 0; S.boom = null; S.scroll = 0; S.dirty = true;
  P.lane = 2; P.x = cx(2); P.y = PY_MAX - 47; P.jumpT = -1;
  keys.up = keys.down = keys.left = keys.right = false;
  hold.left = hold.right = 0;
}

function addScore(n, x, y) {
  var old = S.score;
  S.score += n;
  S.jumps += Math.floor(S.score / 5) - Math.floor(old / 5);   // 每得 5 分补 1 次跳跃
  S.pops.push({ x: x, y: y, t: 0, text: '+' + n });
  if (S.pops.length > 2) S.pops.shift();
}

function moveLane(k) {
  if (k === 'left') P.lane = Math.max(0, P.lane - 1);
  else P.lane = Math.min(LANES - 1, P.lane + 1);
}

function doJump() {
  if (S.state === 'play' && S.jumps > 0 && P.jumpT < 0) {
    S.jumps--;
    P.jumpT = 0;
  }
}

function freeSlot() {
  for (var i = 0; i < MAX_CARS; i++) if (!S.slots[i]) return i;
  return -1;
}

function addCar(type, lane, extra) {
  var slot = freeSlot();
  if (slot < 0) return null;
  var d = TYPES[type];
  var src;
  if (type === 'sedan') src = '/common/sedan_' + ri(SEDAN_COLORS) + '.png';
  else if (type === 'kart') src = '/common/kart_' + ri(KART_COLORS) + '.png';
  else if (type === 'fast') src = '/common/fast.png';
  else if (type === 'moto') src = '/common/moto_' + ri(MOTO_COLORS) + '.png';
  else src = '/common/truck.png';
  var car = {
    type: type, lane: lane, x: cx(lane), y: -d.h / 2 - extra,
    w: d.w, h: d.h, hw: d.hw, hh: d.hh, mult: type === 'kart' ? D.kartMult : d.mult, score: d.score,
    src: src, slot: slot, jumped: false, done: false, wt: rnd(0.3, 1.0)
  };
  S.cars.push(car);
  S.slots[slot] = car;
  S.slotSrc[slot] = src;
  return car;
}

function pickType(l) {
  var r = Math.random();
  var truckP = l >= D.truckFrom ? D.truck[0] + l * D.truck[1] : 0;
  var kartP = l >= D.kartFrom ? D.kart[0] + l * D.kart[1] : 0;
  var motoP = D.moto && l >= D.moto[0] ? D.moto[1] + l * D.moto[2] : 0;
  if (D.moto && l >= D.moto[0] && Math.random() < FAST_P) return 'fast';
  if (r < truckP) return 'truck';
  if (r < truckP + kartP) return 'kart';
  if (r < truckP + kartP + motoP) return 'moto';
  return 'sedan';
}

// 一次出一批车：随机 1~D.lanes 条赛道，每条赛道随机 1~N 辆（N 由难度和级别决定）。
// 上方同时有车的赛道最多 4 条，所以每一刻至少有 1 条空路。
function spawnCar() {
  var l = lvl(), i, c;
  var busy = {}, busyCount = 0;
  for (i = 0; i < S.cars.length; i++) {
    c = S.cars[i];
    if (c.y - c.h / 2 < 130 && !busy[c.lane]) { busy[c.lane] = true; busyCount++; }
  }
  var free = [];
  for (var ln = 0; ln < LANES; ln++) if (!busy[ln]) free.push(ln);
  var maxNew = Math.min(4 - busyCount, free.length);
  if (maxNew < 1 || S.cars.length >= MAX_CARS) { S.spawn = 0.15; return; }
  var k = Math.min(1 + ri(D.lanes), maxNew);         // 这一批出在几条赛道
  for (i = free.length - 1; i > 0; i--) {            // 洗牌，随机挑赛道
    var j = ri(i + 1), tmp = free[i]; free[i] = free[j]; free[j] = tmp;
  }
  var gmax = D.laneCap(l);                           // 每条赛道最多连出几辆
  var total = 0;
  for (i = 0; i < k; i++) {
    var n = 1 + ri(gmax);                            // 这条赛道出几辆
    var extra = 0;
    for (var q = 0; q < n && total < D.batch; q++) {
      var car = addCar(pickType(l), free[i], extra);
      if (!car) break;
      total++;
      extra += car.h + rnd(26, 60);                  // 后一辆排在前一辆身后
    }
  }
  // 出车间隔随级别缩短，出得越多隔得越久（单位 px，再除以车速换成秒）
  var gap = (rnd(110, 170) * (1 - 0.055 * (l - 1)) + 22 * total) * D.gap;
  S.spawn = gap / spd();
}

// 摩托车前方（本道、一个轿车长度以内）有车就算被挡住
function blockerAhead(m, ln, look) {
  var best = null;
  for (var i = 0; i < S.cars.length; i++) {
    var c = S.cars[i];
    if (c === m || c.lane !== ln) continue;
    if (c.y > m.y - (c.h + m.h) / 2 && c.y - c.h / 2 - (m.y + m.h / 2) < look) {
      if (!best || c.y < best.y) best = c;
    }
  }
  return best;
}

// 摩托车换到 ln 道后，上方同时有车的赛道会不会达到 5 条（那样就没有空路了）
function wouldFill(m, ln) {
  if (m.y - m.h / 2 >= 150) return false;
  var seen = [false, false, false, false, false], n = 0, i, c;
  seen[ln] = true; n = 1;
  for (i = 0; i < S.cars.length; i++) {
    c = S.cars[i];
    if (c === m || c.y - c.h / 2 >= 150 || seen[c.lane]) continue;
    seen[c.lane] = true; n++;
  }
  return n >= LANES;
}

// 摩托车：隔一会儿随机换到相邻赛道（乱窜）；本道前方一个轿车距离内有车就马上避开；两边都有车就跟在后面
function moveMoto(m, dt) {
  m.wt -= dt;
  var block = blockerAhead(m, m.lane, 29);
  if (block || m.wt <= 0) {
    var a = m.lane - 1, b = m.lane + 1, t;
    if (Math.random() < 0.5) { t = a; a = b; b = t; }
    var pick = -1;
    if (a >= 0 && a < LANES && !blockerAhead(m, a, 70) && !wouldFill(m, a)) pick = a;
    else if (b >= 0 && b < LANES && !blockerAhead(m, b, 70) && !wouldFill(m, b)) pick = b;
    if (pick >= 0) m.lane = pick;
    m.wt = rnd(0.4, 1.3);
    block = blockerAhead(m, m.lane, 29);
  }
  var tx = cx(m.lane), dx = tx - m.x, st = 80 * dt;
  m.x += dx > st ? st : (dx < -st ? -st : dx);
  if (block) {
    var maxY = block.y - block.h / 2 - m.h / 2 - 3;
    if (m.y > maxY) m.y = maxY;
  }
}

// 极速摩托车：和同一条道上前方的车重叠就爆炸（车和它自己都消失，放一小团火花）
function explodeFast() {
  for (var i = S.cars.length - 1; i >= 0; i--) {
    var f = S.cars[i];
    if (f.type !== 'fast') continue;
    for (var j = 0; j < S.cars.length; j++) {
      var c = S.cars[j];
      if (c === f || c.type === 'fast' || Math.abs(c.x - f.x) > 12 || c.y <= f.y) continue;
      if (c.y - f.y < (c.h + f.h) / 2) {
        S.boom = { x: f.x, y: f.y, t: 0 };
        S.parts = [];
        for (var q = 0; q < MAX_PARTS; q++) {
          var a = Math.random() * Math.PI * 2, v = rnd(30, 120);
          S.parts.push({ x: f.x, y: f.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v, life: rnd(0.4, 0.8), s: 2 + ri(3), c: PARTICLE_COLORS[ri(PARTICLE_COLORS.length)] });
        }
        if (f.slot !== undefined) S.slots[f.slot] = null;
        S.cars.splice(i, 1);
        break;
      }
    }
  }
}

function crash() {
  S.state = 'over';
  S.overT = 0;
  S.dirty = true;
  var z = jumpZ() * 14;
  S.boom = { x: P.x, y: P.y - z, t: 0 };
  S.parts = [];
  for (var i = 0; i < MAX_PARTS; i++) {
    var a = Math.random() * Math.PI * 2;
    var v = rnd(30, 140);
    S.parts.push({
      x: S.boom.x, y: S.boom.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 15,
      life: rnd(0.5, 1.1), s: 2 + ri(3), c: PARTICLE_COLORS[ri(PARTICLE_COLORS.length)]
    });
  }
  if (S.score > S.best) S.best = S.score;
  S.bests[diffIndex] = S.best;
}

function press(k) {
  if (S.state === 'ready') { reset(); return; }
  if (S.state === 'over') { if (S.overT > 0.6) reset(); return; }
  keys[k] = true;
  if (k === 'jump') doJump();
  else if (k === 'left' || k === 'right') { moveLane(k); hold[k] = 0.22; }
  else S.dirty = true;
}

function release(k) { keys[k] = false; }

function tick(dt) {
  var i;
  if (dt > 0.08) dt = 0.08;
  if (dt <= 0) return;
  S.t += dt;

  for (i = 0; i < S.parts.length; i++) {
    var p = S.parts[i];
    p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 50 * dt; p.life -= dt;
  }
  for (i = S.parts.length - 1; i >= 0; i--) if (S.parts[i].life <= 0) S.parts.splice(i, 1);   // 倒序删除，不新建数组
  for (i = 0; i < S.pops.length; i++) S.pops[i].t += dt;
  for (i = S.pops.length - 1; i >= 0; i--) if (S.pops[i].t >= 0.9) S.pops.splice(i, 1);
  if (S.boom) S.boom.t += dt;

  if (S.state === 'over') { S.overT += dt; return; }
  if (S.state !== 'play') return;

  var sp = spd();
  S.scroll += sp * dt;

  var dy = (keys.down ? 1 : 0) - (keys.up ? 1 : 0);
  P.x += (cx(P.lane) - P.x) * Math.min(1, dt * 14);
  P.y = Math.max(PY_MIN, Math.min(PY_MAX, P.y + dy * 150 * dt));   // 最高只能开到圆角的尽头
  var sides = ['left', 'right'];
  for (i = 0; i < 2; i++) {
    var k = sides[i];
    if (keys[k]) {
      hold[k] -= dt;
      if (hold[k] <= 0) { moveLane(k); hold[k] = 0.14; }
    }
  }
  if (P.jumpT >= 0) {
    P.jumpT += dt;
    if (P.jumpT >= JUMP_T) P.jumpT = -1;
  }

  S.spawn -= dt;
  if (S.spawn <= 0) spawnCar();

  for (i = 0; i < S.cars.length; i++) S.cars[i].y += S.cars[i].mult * sp * dt;

  // 同一条道上的车不能叠在一起：后面的车跟在前面的车后面
  var l, ls;
  for (i = 0; i < S.cars.length; i++) if (S.cars[i].type === 'moto') moveMoto(S.cars[i], dt);
  for (l = 0; l < LANES; l++) laneBuf[l].length = 0;
  for (i = 0; i < S.cars.length; i++) if (S.cars[i].type !== 'moto' && S.cars[i].type !== 'fast') laneBuf[S.cars[i].lane].push(S.cars[i]);
  for (l = 0; l < LANES; l++) {
    ls = laneBuf[l];
    if (ls.length > 1) ls.sort(byYDesc);
    for (i = 1; i < ls.length; i++) {
      var maxY = ls[i - 1].y - ls[i - 1].h / 2 - ls[i].h / 2 - 5;
      if (ls[i].y > maxY) ls[i].y = maxY;
    }
  }

  explodeFast();
  var air = airborne();
  for (i = 0; i < S.cars.length; i++) {
    var c = S.cars[i];
    var hit = P.x - 7 < c.x + c.hw && P.x + 7 > c.x - c.hw &&
              P.y - 12 < c.y + c.hh && P.y + 12 > c.y - c.hh;
    if (hit) {
      if (c.type !== 'truck' && air) c.jumped = true;   // 在空中越过轿车/卡丁车
      else { crash(); return; }                         // 落地时重叠，或货车（跳不过）
    }
    if (!c.done && c.y - c.h / 2 > P.y + 12) {
      c.done = true;
      var pts = c.jumped ? c.score : DODGE_SCORE;
      if (pts > 0) addScore(pts, c.x, P.y - 20);
    }
  }
  for (i = S.cars.length - 1; i >= 0; i--) {
    var gone = S.cars[i];
    if (gone.y - gone.h / 2 >= GAME_H + 10) {
      if (gone.slot !== undefined) S.slots[gone.slot] = null;
      S.cars.splice(i, 1);
    }
  }
}

function hasFx() {
  return (S.boom && S.boom.t < 1.3) || S.pops.length > 0 || S.parts.length > 0;
}

// 哪些特效现在有东西要画；没有的话页面就不用每帧重新赋值
function fxActive() {
  return { parts: S.parts.length > 0, pops: S.pops.length > 0, flash: !!(S.boom && S.boom.t < 0.5) };
}

function needsRender() {
  return S.state === 'play' || S.dirty || hasFx();
}

function view() {
  var i, z = jumpZ();
  var cars = [];
  for (i = 0; i < MAX_CARS; i++) {
    var c = S.slots[i];
    var src = S.slotSrc[i] || '/common/sedan_0.png';
    if (c && c.y + c.h / 2 <= 488) cars.push({ src: c.src, l: rd(c.x - c.w / 2), t: rd(c.y - c.h / 2), w: c.w, h: c.h });   // 超出屏幕下沿的先藏起来，页面内容不能超出屏幕，否则手指一划页面会跟着动
    else { HIDDEN_CARS[i].src = src; cars.push(HIDDEN_CARS[i]); }   // 没车的位置藏在屏幕外，图片保持不变，对象复用
  }
  var pl, shadow;
  if (S.state === 'over') pl = { src: '/common/player.png', l: -60, t: -80, w: PW, h: PH };
  else if (z > 0.05) pl = { src: '/common/player_air.png', l: rd(P.x - 12.5), t: rd(P.y - 18 - z * 14), w: 25, h: 36 };
  else pl = { src: '/common/player.png', l: rd(P.x - PW / 2), t: rd(P.y - PH / 2), w: PW, h: PH };
  if (z > 0.05 && S.state !== 'over') shadow = { l: rd(P.x - 9), t: rd(P.y - 10) };
  else shadow = { l: -60, t: -80 };

  var parts = [];
  for (i = 0; i < MAX_PARTS; i++) {
    var q = S.parts[i];
    if (q && q.x < 186 && q.y < 486) parts.push({ l: rd(q.x), t: rd(q.y), s: q.s, c: q.c });
    else parts.push(HIDDEN_PARTS[i]);
  }
  var flash = { l: -100, t: -100, s: 1, o: 0 };
  if (S.boom && S.boom.t < 0.5) {
    var fs = rd(6 + S.boom.t * 110);
    flash = { l: rd(S.boom.x - fs / 2), t: rd(S.boom.y - fs / 2), s: fs, o: Math.round((1 - S.boom.t / 0.5) * 100) / 100 };
  }
  var pops = [];
  for (i = 0; i < 2; i++) {
    var pp = S.pops[i];
    if (pp) pops.push({ l: rd(pp.x - 15), t: rd(pp.y - pp.t * 24), txt: pp.text });
    else pops.push(HIDDEN_POPS[i]);
  }
  return {
    cars: cars, pl: pl, shadow: shadow, parts: parts, flash: flash, pops: pops,
    laneTop: rd(-28 + (S.scroll % 28)),
    laneTop2: rd(-28 + (S.scroll % 28)) + 252,
    score: S.score, level: lvl(), jumps: S.jumps, best: S.best,
    scoreFs: S.score >= 1000 ? 12 : 16,
    showReady: S.state === 'ready',
    showOver: S.state === 'over' && S.overT > 0.8,
    showDiff: S.state === 'ready' || (S.state === 'over' && S.overT > 0.8)
  };
}

function clean() { S.dirty = false; }

// 从存储里读到某个难度的历史最高分，只会往大了改
function setBestFor(i, n) {
  if (i < 0 || i > 3 || !(n > S.bests[i])) return;
  S.bests[i] = n;
  if (i === diffIndex) { S.best = n; S.dirty = true; }
}

var G = {
  S: S, P: P, TYPES: TYPES, JUMP_T: JUMP_T, PY_MIN: PY_MIN,
  reset: reset, press: press, release: release, tick: tick,
  setDifficulty: setDifficulty, setArea: setArea, area: function () { return GAME_H; }, diffName: function () { return D.name; }, speed: spd, DIFFS: DIFFS,
  needsRender: needsRender, fxActive: fxActive, clean: clean, view: view, level: lvl, setBestFor: setBestFor, diffIndex: function () { return diffIndex; }
};

export default G;

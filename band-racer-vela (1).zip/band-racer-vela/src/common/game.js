/*
 * 手环赛车 - 纯游戏逻辑（不碰界面）。
 * 游戏区 192 x 340，y 向下增大。5 条赛道。
 * 页面每 50ms 调一次 tick()，再用 view() 取要显示的内容。
 */
var GAME_H = 340;
var LANES = 5;
var LANE_W = 26;
var ROAD_X = 4;
var MAX_CARS = 9;
var MAX_PARTS = 14;
var JUMP_T = 0.72;      // 跳跃滞空时间（秒）
var DODGE_SCORE = 1;    // 不跳、直接躲开一辆车的得分（设为 0 就只有跳过去才得分）
var SEDAN_COLORS = 7;   // 轿车颜色数量，sedan_0..6，没有红色
var KART_COLORS = 5;
var PW = 20;
var PH = 29;
var PARTICLE_COLORS = ['#fff6b0', '#ffd23a', '#ff9a2e', '#ff5a1f', '#e8262b', '#f4f8ff'];

var TYPES = {
  sedan: { w: 20, h: 29, hw: 7, hh: 12, mult: 1.0, score: 2 },
  kart:  { w: 17, h: 25, hw: 6, hh: 10, mult: 1.4, score: 4 },
  truck: { w: 22, h: 47, hw: 9, hh: 21, mult: 0.85, score: 0 }
};

function cx(l) { return ROAD_X + l * LANE_W + LANE_W / 2; }
function rnd(a, b) { return a + Math.random() * (b - a); }
function ri(n) { return Math.floor(Math.random() * n); }
function rd(n) { return Math.round(n); }

var S = {
  state: 'ready', t: 0, score: 0, jumps: 1, best: 0,
  cars: [], parts: [], pops: [], scroll: 0, spawn: 0.8,
  overT: 0, boom: null, dirty: true
};
var P = { lane: 2, x: cx(2), y: 265, jumpT: -1 };
var keys = { up: false, down: false, left: false, right: false };
var hold = { left: 0, right: 0 };

function lvl() { return Math.min(10, 1 + Math.floor(S.score / 10)); }
function spd() { return (130 + lvl() * 14) * 0.7; }
function jumpZ() { return P.jumpT >= 0 ? Math.sin(Math.PI * P.jumpT / JUMP_T) : 0; }
function airborne() { return jumpZ() > 0.3; }

function reset() {
  S.state = 'play';
  S.score = 0; S.jumps = 1; S.cars = []; S.parts = []; S.pops = [];
  S.spawn = 0.8; S.overT = 0; S.boom = null; S.scroll = 0; S.dirty = true;
  P.lane = 2; P.x = cx(2); P.y = 265; P.jumpT = -1;
  keys.up = keys.down = keys.left = keys.right = false;
  hold.left = hold.right = 0;
}

function addScore(n, x, y) {
  var old = S.score;
  S.score += n;
  S.jumps += Math.floor(S.score / 5) - Math.floor(old / 5);   // 每得 5 分补 1 次跳跃
  S.pops.push({ x: x, y: y, t: 0, text: '+' + n });
  if (S.pops.length > 2) S.pops.shift();
}

function moveLane(k) {
  if (k === 'left') P.lane = Math.max(0, P.lane - 1);
  else P.lane = Math.min(LANES - 1, P.lane + 1);
}

function doJump() {
  if (S.state === 'play' && S.jumps > 0 && P.jumpT < 0) {
    S.jumps--;
    P.jumpT = 0;
  }
}

function addCar(type, lane, extra) {
  var d = TYPES[type];
  var src;
  if (type === 'sedan') src = '/common/sedan_' + ri(SEDAN_COLORS) + '.png';
  else if (type === 'kart') src = '/common/kart_' + ri(KART_COLORS) + '.png';
  else src = '/common/truck.png';
  S.cars.push({
    type: type, lane: lane, x: cx(lane), y: -d.h / 2 - extra,
    w: d.w, h: d.h, hw: d.hw, hh: d.hh, mult: d.mult, score: d.score,
    src: src, jumped: false, done: false
  });
}

function spawnCar() {
  var l = lvl();
  var r = Math.random();
  var truckP = 0.12 + l * 0.012;
  var kartP = 0.22 + l * 0.012;
  var type = r < truckP ? 'truck' : (r < truckP + kartP ? 'kart' : 'sedan');
  var i, busy = {}, busyCount = 0;
  if (S.cars.length >= MAX_CARS - 1) { S.spawn = 0.15; return; }
  for (i = 0; i < S.cars.length; i++) {
    var c = S.cars[i];
    if (c.y < 112 && !busy[c.lane]) { busy[c.lane] = true; busyCount++; }
  }
  if (busyCount >= 2) { S.spawn = 0.15; return; }       // 上方最多同时两条道有车，留出空路
  var free = [];
  for (var ln = 0; ln < LANES; ln++) {
    if (busy[ln]) continue;
    var ok = true;
    for (i = 0; i < S.cars.length; i++) {
      var o = S.cars[i];
      if (o.lane === ln && o.y - o.h / 2 < 50) { ok = false; break; }
    }
    if (ok) free.push(ln);
  }
  if (!free.length) { S.spawn = 0.15; return; }
  var lane = free[ri(free.length)];
  addCar(type, lane, 0);
  var doubled = false;
  if (l >= 3 && busyCount === 0 && free.length > 1 && Math.random() < 0.25) {
    var rest = [];
    for (i = 0; i < free.length; i++) if (free[i] !== lane) rest.push(free[i]);
    var r2 = Math.random();
    addCar(r2 < 0.2 ? 'truck' : (r2 < 0.5 ? 'kart' : 'sedan'), rest[ri(rest.length)], rnd(7, 28));
    doubled = true;
  }
  var gap = (rnd(105, 160) - l * 3.5) * (doubled ? 1.3 : 1);
  S.spawn = gap / spd();
}

function crash() {
  S.state = 'over';
  S.overT = 0;
  S.dirty = true;
  var z = jumpZ() * 14;
  S.boom = { x: P.x, y: P.y - z, t: 0 };
  S.parts = [];
  for (var i = 0; i < MAX_PARTS; i++) {
    var a = Math.random() * Math.PI * 2;
    var v = rnd(30, 140);
    S.parts.push({
      x: S.boom.x, y: S.boom.y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 15,
      life: rnd(0.5, 1.1), s: 2 + ri(3), c: PARTICLE_COLORS[ri(PARTICLE_COLORS.length)]
    });
  }
  if (S.score > S.best) S.best = S.score;
}

function press(k) {
  if (S.state === 'ready') { reset(); return; }
  if (S.state === 'over') { if (S.overT > 0.6) reset(); return; }
  keys[k] = true;
  if (k === 'jump') doJump();
  else if (k === 'left' || k === 'right') { moveLane(k); hold[k] = 0.22; }
  else S.dirty = true;
}

function release(k) { keys[k] = false; }

function tick(dt) {
  var i;
  if (dt > 0.08) dt = 0.08;
  if (dt <= 0) return;
  S.t += dt;

  for (i = 0; i < S.parts.length; i++) {
    var p = S.parts[i];
    p.x += p.vx * dt; p.y += p.vy * dt; p.vy += 50 * dt; p.life -= dt;
  }
  S.parts = S.parts.filter(function (q) { return q.life > 0; });
  for (i = 0; i < S.pops.length; i++) S.pops[i].t += dt;
  S.pops = S.pops.filter(function (q) { return q.t < 0.9; });
  if (S.boom) S.boom.t += dt;

  if (S.state === 'over') { S.overT += dt; return; }
  if (S.state !== 'play') return;

  var sp = spd();
  S.scroll += sp * dt;

  var dy = (keys.down ? 1 : 0) - (keys.up ? 1 : 0);
  P.y = Math.max(185, Math.min(312, P.y + dy * 120 * dt));
  P.x += (cx(P.lane) - P.x) * Math.min(1, dt * 14);
  var sides = ['left', 'right'];
  for (i = 0; i < 2; i++) {
    var k = sides[i];
    if (keys[k]) {
      hold[k] -= dt;
      if (hold[k] <= 0) { moveLane(k); hold[k] = 0.14; }
    }
  }
  if (P.jumpT >= 0) {
    P.jumpT += dt;
    if (P.jumpT >= JUMP_T) P.jumpT = -1;
  }

  S.spawn -= dt;
  if (S.spawn <= 0) spawnCar();

  for (i = 0; i < S.cars.length; i++) S.cars[i].y += S.cars[i].mult * sp * dt;

  // 同一条道上的车不能叠在一起：后面的车跟在前面的车后面
  for (var l = 0; l < LANES; l++) {
    var ls = S.cars.filter(function (c) { return c.lane === l; });
    ls.sort(function (a, b) { return b.y - a.y; });
    for (i = 1; i < ls.length; i++) {
      var maxY = ls[i - 1].y - ls[i - 1].h / 2 - ls[i].h / 2 - 5;
      if (ls[i].y > maxY) ls[i].y = maxY;
    }
  }

  var air = airborne();
  for (i = 0; i < S.cars.length; i++) {
    var c = S.cars[i];
    var hit = P.x - 7 < c.x + c.hw && P.x + 7 > c.x - c.hw &&
              P.y - 12 < c.y + c.hh && P.y + 12 > c.y - c.hh;
    if (hit) {
      if (c.type !== 'truck' && air) c.jumped = true;   // 在空中越过轿车/卡丁车
      else { crash(); return; }                         // 落地时重叠，或货车（跳不过）
    }
    if (!c.done && c.y - c.h / 2 > P.y + 12) {
      c.done = true;
      var pts = c.jumped ? c.score : DODGE_SCORE;
      if (pts > 0) addScore(pts, c.x, P.y - 20);
    }
  }
  S.cars = S.cars.filter(function (c) { return c.y - c.h / 2 < GAME_H + 10; });
}

function hasFx() {
  return (S.boom && S.boom.t < 1.3) || S.pops.length > 0 || S.parts.length > 0;
}

function needsRender() {
  return S.state === 'play' || S.dirty || hasFx();
}

function view() {
  var i, z = jumpZ();
  var cars = [];
  for (i = 0; i < MAX_CARS; i++) {
    var c = S.cars[i];
    if (c) cars.push({ src: c.src, l: rd(c.x - c.w / 2), t: rd(c.y - c.h / 2), w: c.w, h: c.h });
    else cars.push({ src: '/common/sedan_0.png', l: -60, t: -80, w: 20, h: 29 });
  }
  var pl, shadow;
  if (S.state === 'over') pl = { src: '/common/player.png', l: -60, t: -80, w: PW, h: PH };
  else if (z > 0.05) pl = { src: '/common/player_air.png', l: rd(P.x - 12.5), t: rd(P.y - 18 - z * 14), w: 25, h: 36 };
  else pl = { src: '/common/player.png', l: rd(P.x - PW / 2), t: rd(P.y - PH / 2), w: PW, h: PH };
  if (z > 0.05 && S.state !== 'over') shadow = { l: rd(P.x - 9), t: rd(P.y - 10) };
  else shadow = { l: -60, t: -80 };

  var parts = [];
  for (i = 0; i < MAX_PARTS; i++) {
    var q = S.parts[i];
    if (q) parts.push({ l: rd(q.x), t: rd(q.y), s: q.s, c: q.c });
    else parts.push({ l: -30, t: -30, s: 2, c: '#ffd23a' });
  }
  var flash = { l: -100, t: -100, s: 1, o: 0 };
  if (S.boom && S.boom.t < 0.5) {
    var fs = rd(6 + S.boom.t * 110);
    flash = { l: rd(S.boom.x - fs / 2), t: rd(S.boom.y - fs / 2), s: fs, o: Math.round((1 - S.boom.t / 0.5) * 100) / 100 };
  }
  var pops = [];
  for (i = 0; i < 2; i++) {
    var pp = S.pops[i];
    if (pp) pops.push({ l: rd(pp.x - 15), t: rd(pp.y - pp.t * 24), txt: pp.text });
    else pops.push({ l: -60, t: -60, txt: '' });
  }
  var n = Math.min(S.jumps, 6);
  var squares = [];
  for (i = 0; i < n; i++) squares.push({ l: 150 + (i % 2) * 20, t: 208 + Math.floor(i / 2) * 18 });

  return {
    cars: cars, pl: pl, shadow: shadow, parts: parts, flash: flash, pops: pops,
    squares: squares, jumpMore: S.jumps > 6,
    laneTop: rd(-28 + (S.scroll % 28)),
    score: S.score, level: lvl(), jumps: S.jumps, best: S.best,
    scoreFs: S.score >= 1000 ? 12 : 16,
    showReady: S.state === 'ready',
    showOver: S.state === 'over' && S.overT > 0.8
  };
}

function clean() { S.dirty = false; }

// 从存储里读到的历史最高分，只会往大了改
function setBest(n) {
  if (n > S.best) { S.best = n; S.dirty = true; }
}

var G = {
  S: S, P: P, TYPES: TYPES, JUMP_T: JUMP_T,
  reset: reset, press: press, release: release, tick: tick,
  needsRender: needsRender, clean: clean, view: view, level: lvl, setBest: setBest
};

export default G;

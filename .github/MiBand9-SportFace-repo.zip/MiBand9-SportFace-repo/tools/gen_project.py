import os, sys, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import xmltodict
from PIL import Image, ImageDraw
import make as M

ROOT = "/tmp/claude-0/-home-claude/41fe6e7d-f332-51f2-8ecc-5c58f30f451c/scratchpad/out/MiBand9-SportFace-repo"
FACE = os.path.join(ROOT, "face")
IMG = os.path.join(FACE, "images")
ASSETS = os.path.join(ROOT, "assets")
FACE_ID = "812024001"   # 9 digits; written into the binary at offset 40 by the workflow
NAME = "SportFace"

shutil.rmtree(ROOT, ignore_errors=True)
os.makedirs(IMG)

# 1) regenerate the whole asset pack into the repo (also yields bg + sample preview)
M.OUT = ASSETS
M.main()

def save(im, name):
    im.save(os.path.join(IMG, name))

# 2) flat, ASCII-named image set for the project
bg = M.down(M.background(), M.W, M.H).convert("RGBA")
save(bg, "bg.png")
shutil.copy(os.path.join(ASSETS, "01_preview_sample_192x490.png"), os.path.join(IMG, "preview.png"))

sets = {"time": M.TIME, "sec": M.SEC, "date": M.DATE, "hr": M.HR, "card": M.CARD, "temp": M.TEMP}
for name, spec in sets.items():
    for ch in "0123456789":
        save(M.digit_png(ch, spec), f"{name}_{ch}.png")
ms = M.new(M.TEMP['w'], M.TEMP['h']); md = ImageDraw.Draw(ms, "RGBA")
M.draw_char(md, '-', 0, 0, M.TEMP['w'], M.TEMP['h'], M.TEMP['t'], ghost=False)
save(M.down(ms, M.TEMP['w'], M.TEMP['h']), "temp_minus.png")

# uniform 7x10 battery digits (light on the black disc)
for ch in "0123456789":
    im = M.new(M.BAT['w'], M.BAT['h'])
    d = ImageDraw.Draw(im, "RGBA")
    M.text(d, ch, M.BAT['w'] / 2, M.BAT['h'] / 2 + 0.3, 9.5, M.LIGHT, M.BLACK, anchor="mm")
    save(M.down(im, M.BAT['w'], M.BAT['h']), f"bat_{ch}.png")

# battery ring: one frame per percent (0..100)
for p in range(101):
    save(M.ring_png(round(p * 24 / 100)), f"ring_{p:03d}.png")

# weekday: index 0 = Sunday ... 6 = Saturday (same size for all)
wk = []
for i, wd in enumerate("日一二三四五六"):
    wk.append(M.text_png("星期" + wd, 15, M.DARK, M.BLACK, spacing=0.5))
mw = max(i.width for i in wk); mh = max(i.height for i in wk)
for i, im in enumerate(wk):
    canvas = Image.new("RGBA", (mw, mh), (0, 0, 0, 0))
    canvas.paste(im, ((mw - im.width) // 2, (mh - im.height) // 2))
    save(canvas, f"wk_{i}.png")

# invisible tap areas
save(Image.new("RGBA", (66, 28), (0, 0, 0, 0)), "tap_hrm.png")
save(Image.new("RGBA", (40, 40), (0, 0, 0, 0)), "tap_alarm.png")

# 3) project XML
widgets = []
def common(name, x, y, w, h):
    return {"@Name": name, "@X": str(int(round(x))), "@Y": str(int(round(y))), "@Width": str(int(w)), "@Height": str(int(h)),
            "@Alpha": "255", "@Visible_Src": "0"}

def image(name, bitmap, x, y, w, h):
    d = {"@Shape": "30"}; d.update(common(name, x, y, w, h)); d["@Bitmap"] = bitmap
    widgets.append(d)

def imagelist(name, items, src, x, y, w, h):
    d = {"@Shape": "31"}; d.update(common(name, x, y, w, h))
    d.update({"@BitmapList": "|".join(f"({i}):{f}" for i, f in items), "@Alignment": "0", "@DefaultIndex": "0",
              "@Index_Src": src, "@Value_Src": "0", "@Spacing": "0", "@Blanking": "0"})
    widgets.append(d)

ALIGN = {"left": "0", "center": "1", "right": "2"}
def number(name, prefix, spec, src, digits, x, y, align, hide_zeros, extra=None):
    files = [f"{prefix}_{i}.png" for i in range(10)] + (extra or [])
    sp = int(round(spec['gap']))
    w = digits * (int(spec['w']) + sp) - sp
    d = {"@Shape": "32"}; d.update(common(name, x, y, w, spec['h']))
    d.update({"@BitmapList": "|".join(files), "@Digits": str(digits), "@Alignment": ALIGN[align], "@Value_Src": src,
              "@Spacing": str(sp), "@Blanking": "1" if hide_zeros else "0"})
    widgets.append(d)

S = M.SLOTS
image("bg", "bg.png", 0, 0, 192, 490)
imagelist("battery_ring", [(p, f"ring_{p:03d}.png") for p in range(101)], "0841", 19, 25, 50, 50)
number("battery_num", "bat", M.BAT | {"gap": 0}, "0841", 3, M.BAT_SLOTS[0][0], M.BAT_SLOTS[0][1], "right", True)
imagelist("weekday", [(i, f"wk_{i}.png") for i in range(7)], "2012", M.L['weekday'][0] - 1, M.L['weekday'][1], mw, mh)
number("month", "date", M.DATE, "1012", 2, S['date'][0][0], S['date'][0][1], "right", False)
number("day", "date", M.DATE, "1812", 2, S['date'][3][0], S['date'][3][1], "right", False)
number("hr_num", "hr", M.HR, "0822", 3, S['hr'][0][0], S['hr'][0][1], "left", True)
number("hour", "time", M.TIME, "0811", 2, S['time'][0][0], S['time'][0][1], "right", False)
number("minute", "time", M.TIME, "1011", 2, S['time'][2][0], S['time'][2][1], "right", False)
number("second", "sec", M.SEC, "1811", 2, S['sec'][0][0], S['sec'][0][1], "right", False)
number("steps", "card", M.CARD, "0821", 5, S['steps'][0][0], S['steps'][0][1], "right", True)
number("calories", "card", M.CARD, "0823", 4, S['cal'][0][0], S['cal'][0][1], "right", True)
number("stand", "card", M.CARD, "0824", 2, S['stand'][0][0], S['stand'][0][1], "right", True)
number("sleep_score", "card", M.CARD, "0828", 3, S['sleep'][0][0], S['sleep'][0][1], "right", True)
number("temp", "temp", M.TEMP, "2031", 2, S['temp'][0][0], S['temp'][0][1], "right", True, extra=["temp_minus.png"])
image("btn_[hrm]", "tap_hrm.png", 14, 76, 66, 28)
image("btn_[alarm]", "tap_alarm.png", 140, 356, 40, 40)

doc = {"FaceProject": {"@DeviceType": "366", "@Id": FACE_ID,
                       "Screen": {"@Title": "Sport LCD", "@Bitmap": "preview.png", "Widget": widgets}}}
with open(os.path.join(FACE, f"{NAME}.fprj"), "w", encoding="utf8") as f:
    f.write(xmltodict.unparse(doc, pretty=True))

# 4) self-check: every referenced image exists, digit sets are uniform
files = set(os.listdir(IMG))
missing = []
for w in widgets:
    refs = []
    if "@Bitmap" in w: refs.append(w["@Bitmap"])
    if "@BitmapList" in w:
        for it in w["@BitmapList"].split("|"):
            refs.append(it.split(":", 1)[1] if it.startswith("(") else it)
    missing += [r for r in refs if r not in files]
assert not missing, missing
for prefix in ("time", "sec", "date", "hr", "card", "temp", "bat"):
    sizes = {Image.open(os.path.join(IMG, f"{prefix}_{i}.png")).size for i in range(10)}
    assert len(sizes) == 1, (prefix, sizes)
print("widgets:", len(widgets), "images:", len(files))

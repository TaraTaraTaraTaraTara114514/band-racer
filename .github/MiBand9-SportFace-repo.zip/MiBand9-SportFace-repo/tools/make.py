import os, math, json, csv
import numpy as np
from PIL import Image, ImageDraw, ImageFont, ImageFilter

OUT = "/tmp/claude-0/-home-claude/41fe6e7d-f332-51f2-8ecc-5c58f30f451c/scratchpad/out/MiBand9_SportFace_assets"
SS = 8  # supersample
W, H = 192, 490

BOLD = "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc"
BLACK = "/usr/share/fonts/opentype/noto/NotoSansCJK-Black.ttc"

def font(path, px):
    return ImageFont.truetype(path, int(round(px * SS)), index=2)

DARK = (16, 18, 16, 255)
FAINT = (16, 18, 16, 22)
LIGHT = (230, 232, 226, 255)
LCD = (214, 216, 211, 255)
EDGE = (35, 38, 34, 255)
BTN = (27, 29, 26, 255)
TITLE = (43, 46, 42, 255)
DISC = (6, 7, 6, 255)

MAP = {'0': 'abcdef', '1': 'bc', '2': 'abdeg', '3': 'abcdg', '4': 'bcfg',
       '5': 'acdfg', '6': 'acdefg', '7': 'abc', '8': 'abcdefg', '9': 'abcdfg', '-': 'g'}

def seg_poly(k, w, h, t):
    half = h / 2
    r = t / 2
    if k in 'adg':
        y = {'a': 0, 'g': half - r, 'd': h - t}[k]
        x0 = t * 0.6
        ww = w - 1.2 * t
        return [(x0, y + t / 2), (x0 + r, y), (x0 + ww - r, y), (x0 + ww, y + t / 2), (x0 + ww - r, y + t), (x0 + r, y + t)]
    x = {'f': 0, 'e': 0, 'b': w - t, 'c': w - t}[k]
    y0 = {'f': t * 0.6, 'b': t * 0.6, 'e': half + t * 0.2, 'c': half + t * 0.2}[k]
    hh = half - t * 0.8
    return [(x + t / 2, y0), (x + t, y0 + r), (x + t, y0 + hh - r), (x + t / 2, y0 + hh), (x, y0 + hh - r), (x, y0 + r)]

def new(w, h, fill=(0, 0, 0, 0)):
    return Image.new("RGBA", (int(math.ceil(w * SS)), int(math.ceil(h * SS))), fill)

def down(img, w, h):
    return img.resize((int(math.ceil(w)), int(math.ceil(h))), Image.LANCZOS)

def draw_char(d, ch, ox, oy, w, h, t, ghost=True, lit=True):
    on = MAP.get(ch, '')
    for k in 'abcdefg':
        is_on = k in on
        if is_on and lit:
            col = DARK
        elif ghost:
            col = FAINT
        else:
            continue
        pts = [((ox + x) * SS, (oy + y) * SS) for x, y in seg_poly(k, w, h, t)]
        d.polygon(pts, fill=col)

def rrect(d, x, y, w, h, r, fill=None, outline=None, bw=0):
    d.rounded_rectangle([x * SS, y * SS, (x + w) * SS - 1, (y + h) * SS - 1], radius=r * SS, fill=fill,
                        outline=outline, width=int(bw * SS))

def text(d, s, x, y, px, col, path=BOLD, spacing=0.0, anchor="la"):
    f = font(path, px)
    cx = x * SS
    if spacing == 0:
        d.text((cx, y * SS), s, font=f, fill=col, anchor=anchor)
        return
    for c in s:
        d.text((cx, y * SS), c, font=f, fill=col, anchor=anchor)
        cx += f.getlength(c) + spacing * SS

def text_w(s, px, path=BOLD, spacing=0.0):
    f = font(path, px)
    return sum(f.getlength(c) for c in s) / SS + spacing * (len(s) - 1) if spacing else f.getlength(s) / SS

# ---------- icon drawing (stroke icons in a 24x24 viewbox) ----------
def stroke_line(d, pts, sw, col, sc, ox, oy):
    p = [(ox + x * sc, oy + y * sc) for x, y in pts]
    wpx = sw * sc
    d.line([(a * SS, b * SS) for a, b in p], fill=col, width=int(round(wpx * SS)), joint="curve")
    for a, b in (p[0], p[-1]):
        rr = wpx / 2
        d.ellipse([(a - rr) * SS, (b - rr) * SS, (a + rr) * SS, (b + rr) * SS], fill=col)

def stroke_circle(d, cx, cy, r, sw, col, sc, ox, oy):
    wpx = sw * sc
    x0, y0 = ox + (cx - r) * sc, oy + (cy - r) * sc
    x1, y1 = ox + (cx + r) * sc, oy + (cy + r) * sc
    d.ellipse([x0 * SS, y0 * SS, x1 * SS, y1 * SS], outline=col, width=int(round(wpx * SS)))

def stroke_ellipse(d, cx, cy, rx, ry, sw, col, sc, ox, oy):
    wpx = sw * sc
    d.ellipse([(ox + (cx - rx) * sc) * SS, (oy + (cy - ry) * sc) * SS, (ox + (cx + rx) * sc) * SS, (oy + (cy + ry) * sc) * SS],
              outline=col, width=int(round(wpx * SS)))

def icon_clock(d, size, col, ox=0, oy=0):
    sc = size / 24
    stroke_circle(d, 12, 13.5, 7.5, 1.8, col, sc, ox, oy)
    stroke_line(d, [(12, 9.5), (12, 13.7), (14.6, 15.3)], 1.8, col, sc, ox, oy)
    stroke_line(d, [(3.8, 6), (6.8, 3.4)], 1.8, col, sc, ox, oy)
    stroke_line(d, [(20.2, 6), (17.2, 3.4)], 1.8, col, sc, ox, oy)

def icon_home(d, size, col, ox=0, oy=0):
    sc = size / 24
    stroke_line(d, [(3, 11.2), (12, 3.5), (21, 11.2)], 1.8, col, sc, ox, oy)
    stroke_line(d, [(5.5, 9.8), (5.5, 20.5), (18.5, 20.5), (18.5, 9.8)], 1.8, col, sc, ox, oy)
    stroke_line(d, [(10, 20.5), (10, 14.5), (14, 14.5), (14, 20.5)], 1.8, col, sc, ox, oy)

def icon_wechat(d, size, col, ox=0, oy=0):
    sc = size / 24
    stroke_ellipse(d, 9, 10.2, 6.6, 5.6, 1.8, col, sc, ox, oy)
    stroke_line(d, [(5.2, 14.4), (4.3, 17), (7.2, 15.8)], 1.8, col, sc, ox, oy)
    stroke_ellipse(d, 15.7, 14.6, 5.6, 4.6, 1.8, col, sc, ox, oy)
    stroke_line(d, [(19.2, 18), (19.6, 20.2), (17.4, 19.2)], 1.8, col, sc, ox, oy)

def icon_heart(size, col):
    img = new(size, size)
    d = ImageDraw.Draw(img, "RGBA")
    sc = size / 24
    pts = []
    # heart via parametric curve
    for i in range(0, 361, 2):
        a = math.radians(i)
        x = 16 * math.sin(a) ** 3
        y = -(13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a))
        pts.append(((12 + x * 0.6) * sc * SS, (11.2 + y * 0.6) * sc * SS))
    d.polygon(pts, fill=col)
    return down(img, size, size)

def cloud_mask(size, scale=1.0, ox=0, oy=0):
    m = Image.new("L", (int(size * SS), int(size * SS)), 0)
    d = ImageDraw.Draw(m)
    sc = size / 24 * scale
    def circ(cx, cy, r):
        d.ellipse([(ox + (cx - r) * sc) * SS, (oy + (cy - r) * sc) * SS, (ox + (cx + r) * sc) * SS, (oy + (cy + r) * sc) * SS], fill=255)
    circ(6.8, 16.2, 3.8)
    circ(11.5, 12.8, 5.2)
    circ(16.3, 16.2, 3.8)
    d.rectangle([(ox + 6.8 * sc) * SS, (oy + 14.5 * sc) * SS, (ox + 16.3 * sc) * SS, (oy + 20 * sc) * SS], fill=255)
    return m

def outline_from_mask(mask, wpx, col):
    k = int(round(wpx * SS)) | 1
    inner = mask.filter(ImageFilter.MinFilter(k))
    ring = Image.fromarray(np.clip(np.array(mask, dtype=int) - np.array(inner, dtype=int), 0, 255).astype('uint8'))
    img = Image.new("RGBA", mask.size, col[:3] + (0,))
    img.putalpha(ring)
    return img

def weather_icon(kind, size, col=DARK):
    img = new(size, size)
    d = ImageDraw.Draw(img, "RGBA")
    sc = size / 24
    sw = 1.8
    if kind == "sunny":
        stroke_circle(d, 12, 12, 4.2, sw, col, sc, 0, 0)
        for i in range(8):
            a = math.radians(i * 45)
            stroke_line(d, [(12 + math.cos(a) * 6.8, 12 + math.sin(a) * 6.8), (12 + math.cos(a) * 9.2, 12 + math.sin(a) * 9.2)], sw, col, sc, 0, 0)
        return down(img, size, size)
    if kind == "cloudy":  # 多云: sun + cloud
        stroke_circle(d, 17, 6.5, 2.6, sw, col, sc, 0, 0)
        for a in (-90, 0, -45, -135):
            ar = math.radians(a)
            stroke_line(d, [(17 + math.cos(ar) * 4.4, 6.5 + math.sin(ar) * 4.4), (17 + math.cos(ar) * 5.8, 6.5 + math.sin(ar) * 5.8)], sw, col, sc, 0, 0)
        m = cloud_mask(size, 0.92, 0.2, 2.2)
        img = Image.alpha_composite(img, outline_from_mask(m, sw * sc, col))
        return down(img, size, size)
    m = cloud_mask(size, 1.0, 0, -2)
    img = Image.alpha_composite(img, outline_from_mask(m, sw * sc, col))
    d = ImageDraw.Draw(img, "RGBA")
    if kind == "overcast":
        pass
    elif kind == "rain":
        for x in (8, 12, 16):
            stroke_line(d, [(x, 19), (x - 1.4, 22.4)], sw, col, sc, 0, 0)
    elif kind == "snow":
        for x in (8, 12, 16):
            stroke_circle(d, x, 21, 0.6, 1.2, col, sc, 0, 0)
    return down(img, size, size)

# ---------- layout (native pixels) ----------
L = dict(
    top=(12, 18, 168, 90),
    disc=(19, 25, 50, 50),
    heart=(20, 81, 15, 15),
    hr=(37, 82),          # 2 digits  8x14 t2 gap2
    weekday=(76, 22),
    date=(76, 43),        # 5 slots 12x23 t3 gap3
    lunar=(76, 74),
    brand1=(76, 94),
    timepanel=(12, 114, 168, 82),
    time=(18, 134),       # 25x54 t5.5 gap4
    sec=(148, 165),       # 11x23 t3 gap3
    cards=[("steps", 12, 202, "步数"), ("cal", 98, 202, "热量"), ("stand", 12, 274, "站立"), ("sleep", 98, 274, "睡眠")],
    btn=dict(alipay=(12, 356, 40), alarm=(140, 356, 40), wechat=(12, 406, 40), home=(140, 406, 40)),
    weather_block=(66, 354, 60, 44),
    temp=(66, 410, 60, 32),
)
TIME = dict(w=25, h=54, t=5.5, gap=4)
SEC = dict(w=11, h=23, t=3, gap=3)
DATE = dict(w=12, h=23, t=3, gap=3)
HR = dict(w=8, h=14, t=2, gap=2)
CARD = dict(w=11, h=25, t=3, gap=2)
TEMP = dict(w=10, h=19, t=2.5, gap=3)

def card_inner(cx, cy):
    # LCD window of a card
    return (cx + 6, cy + 26, 71, 37)

def card_slots(n, cx, cy):
    ix, iy, iw, ih = card_inner(cx, cy)
    total = n * CARD['w'] + (n - 1) * CARD['gap']
    x0 = ix + (iw - total) // 2
    return [(x0 + i * (CARD['w'] + CARD['gap']), iy + 6) for i in range(n)]

SLOTS = {}
SLOTS['time'] = [(L['time'][0] + i * (TIME['w'] + TIME['gap']), L['time'][1]) for i in (0, 1)] + \
                [(L['time'][0] + 2 * (TIME['w'] + TIME['gap']) + 8 + TIME['gap'] + i * (TIME['w'] + TIME['gap']), L['time'][1]) for i in (0, 1)]
COLON_X = L['time'][0] + 2 * (TIME['w'] + TIME['gap'])
SLOTS['sec'] = [(L['sec'][0] + i * (SEC['w'] + SEC['gap']), L['sec'][1]) for i in (0, 1)]
SLOTS['date'] = [(L['date'][0] + i * (DATE['w'] + DATE['gap']), L['date'][1]) for i in range(5)]
SLOTS['hr'] = [(L['hr'][0] + i * (HR['w'] + HR['gap']), L['hr'][1]) for i in range(3)]
SLOTS['steps'] = card_slots(5, 12, 202)
SLOTS['cal'] = card_slots(4, 98, 202)
SLOTS['stand'] = card_slots(2, 12, 274)
# sleep: d . d  + h
_ix, _iy, _iw, _ih = card_inner(98, 274)
_tot = CARD['w'] * 2 + CARD['gap'] * 2 + 4 + 8
_x0 = _ix + (_iw - _tot) / 2
SLEEP_MODE = 'score'
SLOTS['sleep'] = [(_x0, _iy + 6), (_x0 + CARD['w'] + CARD['gap'] + 4 + CARD['gap'], _iy + 6)]
if SLEEP_MODE == 'score':
    SLOTS['sleep'] = card_slots(3, 98, 274)
SLEEP_DOT = (_x0 + CARD['w'] + CARD['gap'], _iy + 6 + CARD['h'] - 4)
SLEEP_H = (_x0 + 2 * CARD['w'] + 2 * CARD['gap'] + 4 + 3, _iy + 15)
_tix = L['temp'][0] + 2 + 0
SLOTS['temp'] = [(L['temp'][0] + 2 + (57 - 30) // 2 + i * (TEMP['w'] + TEMP['gap']), L['temp'][1] + 2 + 4) for i in range(2)]
BAT = dict(w=7, h=10)
BAT_SLOTS = [(30 + i * 7, 45) for i in range(3)]
BAT_PCT = (55.5, 50.5)
DEG = (SLOTS['temp'][1][0] + TEMP['w'] + TEMP['gap'], SLOTS['temp'][0][1] + 1)

# ---------- background ----------
def make_bg(with_data=None):
    img = new(W, H)
    # screen gradient
    ww, hh = img.size
    yy, xx = np.mgrid[0:hh, 0:ww]
    cx, cy = ww * 0.5, hh * 0.38
    far = math.hypot(max(cx, ww - cx), max(cy, hh - cy))
    t = np.clip(np.hypot(xx - cx, yy - cy) / far, 0, 1)
    c0 = np.array([203, 205, 200]); c1 = np.array([185, 187, 182])
    arr = (c0[None, None, :] * (1 - t[..., None]) + c1[None, None, :] * t[..., None]).astype('uint8')
    arr = np.dstack([arr, np.full((hh, ww), 255, 'uint8')])
    img = Image.fromarray(arr, "RGBA")
    d = ImageDraw.Draw(img, "RGBA")

    # top panel
    x, y, w, h = L['top']
    rrect(d, x, y, w, h, 9, fill=LCD, outline=EDGE, bw=2)
    # battery disc
    dx, dy, dd, _ = L['disc']
    d.ellipse([dx * SS, dy * SS, (dx + dd) * SS, (dy + dd) * SS], fill=DISC, outline=EDGE, width=int(1.5 * SS))
    # heart
    hx, hy, hs, _ = L['heart']
    hi = icon_heart(hs * SS, (212, 56, 13, 255))
    img.paste(hi.resize((hs * SS, hs * SS), Image.LANCZOS), (hx * SS, hy * SS), hi.resize((hs * SS, hs * SS), Image.LANCZOS))
    d = ImageDraw.Draw(img, "RGBA")
    # ghost digits
    for i, (sx, sy) in enumerate(SLOTS['hr']):
        draw_char(d, '8', sx, sy, HR['w'], HR['h'], HR['t'], ghost=True, lit=False)
    for i, (sx, sy) in enumerate(SLOTS['date']):
        if i == 2:
            draw_char(d, '-', sx, sy, DATE['w'], DATE['h'], DATE['t'])
        else:
            draw_char(d, '8', sx, sy, DATE['w'], DATE['h'], DATE['t'], ghost=True, lit=False)
    text(d, "SPORT WATCH", L['brand1'][0], L['brand1'][1], 6.5, (16, 18, 16, 185), BLACK, spacing=1.4)

    # time panel
    x, y, w, h = L['timepanel']
    rrect(d, x, y, w, h, 9, fill=LCD, outline=EDGE, bw=2)
    text(d, "SPORT", x + 8, y + 6, 6.5, (16, 18, 16, 185), BLACK, spacing=1.4)
    for sx, sy in SLOTS['time']:
        draw_char(d, '8', sx, sy, TIME['w'], TIME['h'], TIME['t'], ghost=True, lit=False)
    for yf in (0.3, 0.7):
        cyy = L['time'][1] + TIME['h'] * yf
        d.rectangle([(COLON_X + 1.5) * SS, (cyy - 2.75) * SS, (COLON_X + 1.5 + 5.5) * SS, (cyy + 2.75) * SS], fill=DARK)
    for sx, sy in SLOTS['sec']:
        draw_char(d, '8', sx, sy, SEC['w'], SEC['h'], SEC['t'], ghost=True, lit=False)

    # cards
    for key, cx0, cy0, title in L['cards']:
        rrect(d, cx0, cy0, 82, 68, 9, fill=(191, 193, 188, 255), outline=EDGE, bw=2)
        # title bar (inside border)
        d.rounded_rectangle([(cx0 + 2) * SS, (cy0 + 2) * SS, (cx0 + 80) * SS - 1, (cy0 + 22) * SS], radius=7 * SS, fill=TITLE)
        d.rectangle([(cx0 + 2) * SS, (cy0 + 12) * SS, (cx0 + 80) * SS - 1, (cy0 + 22) * SS], fill=TITLE)
        tw = text_w(title, 11, BOLD, 2)
        text(d, title, cx0 + 41 - tw / 2 + 1, cy0 + 12, 11, LIGHT, BOLD, spacing=2, anchor="lm")
        ix, iy, iw, ih = card_inner(cx0, cy0)
        rrect(d, ix, iy, iw, ih, 4, fill=LCD)
        for sx, sy in SLOTS[key]:
            draw_char(d, '8', sx, sy, CARD['w'], CARD['h'], CARD['t'], ghost=True, lit=False)
    d.rectangle([SLEEP_DOT[0] * SS, SLEEP_DOT[1] * SS, (SLEEP_DOT[0] + 4) * SS, (SLEEP_DOT[1] + 4) * SS], fill=DARK)
    text(d, "h", SLEEP_H[0], SLEEP_H[1], 12, DARK, BLACK)

    # buttons
    for name, (bx, by, bs) in L['btn'].items():
        d.ellipse([bx * SS, by * SS, (bx + bs) * SS, (by + bs) * SS], fill=BTN, outline=EDGE, width=int(1.5 * SS))
        if name == "alipay":
            text(d, "支", bx + bs / 2, by + bs / 2 + 0.5, 19, LIGHT, BLACK, anchor="mm")
        elif name == "alarm":
            icon_clock(d, 20, LIGHT, bx + 10, by + 10)
        elif name == "wechat":
            icon_wechat(d, 20, LIGHT, bx + 10, by + 10)
        elif name == "home":
            icon_home(d, 20, LIGHT, bx + 10, by + 10)

    # temperature box
    x, y, w, h = L['temp']
    rrect(d, x, y, w, h, 5, fill=LCD, outline=EDGE, bw=1.5)
    for sx, sy in SLOTS['temp']:
        draw_char(d, '8', sx, sy, TEMP['w'], TEMP['h'], TEMP['t'], ghost=True, lit=False)
    dgx, dgy = DEG
    d.ellipse([dgx * SS, dgy * SS, (dgx + 5) * SS, (dgy + 5) * SS], outline=DARK, width=int(1.5 * SS))

    out = down(img, W, H) if img.size != (W, H) else img
    return out

def make_bg_ss():
    return None

# The background is built at supersampled size via ImageDraw at W*SS x H*SS. Rebuild with proper canvas:
def build_background():
    big = new(W, H)
    # gradient at big scale
    ww, hh = big.size
    yy, xx = np.mgrid[0:hh, 0:ww]
    cx, cy = ww * 0.5, hh * 0.38
    far = math.hypot(max(cx, ww - cx), max(cy, hh - cy))
    t = np.clip(np.hypot(xx - cx, yy - cy) / far, 0, 1)
    c0 = np.array([203, 205, 200]); c1 = np.array([185, 187, 182])
    arr = (c0[None, None, :] * (1 - t[..., None]) + c1[None, None, :] * t[..., None]).astype('uint8')
    arr = np.dstack([arr, np.full((hh, ww), 255, 'uint8')])
    return Image.fromarray(arr, "RGBA")

def background():
    img = build_background().convert("RGB")
    d = ImageDraw.Draw(img, "RGBA")
    x, y, w, h = L['top']
    rrect(d, x, y, w, h, 9, fill=LCD, outline=EDGE, bw=2)
    dx, dy, dd, _ = L['disc']
    d.ellipse([dx * SS, dy * SS, (dx + dd) * SS, (dy + dd) * SS], fill=DISC, outline=EDGE, width=int(1.5 * SS))
    hx, hy, hs, _ = L['heart']
    hi = icon_heart(hs * SS, (212, 56, 13, 255))
    img.paste(hi, (hx * SS, hy * SS), hi)
    d = ImageDraw.Draw(img, "RGBA")
    for sx, sy in SLOTS['hr']:
        draw_char(d, '8', sx, sy, HR['w'], HR['h'], HR['t'], ghost=True, lit=False)
    for i, (sx, sy) in enumerate(SLOTS['date']):
        if i == 2:
            draw_char(d, '-', sx, sy, DATE['w'], DATE['h'], DATE['t'])
        else:
            draw_char(d, '8', sx, sy, DATE['w'], DATE['h'], DATE['t'], ghost=True, lit=False)
    text(d, "SPORT WATCH", L['brand1'][0], L['brand1'][1], 6.5, (16, 18, 16, 185), BLACK, spacing=1.4)

    x, y, w, h = L['timepanel']
    rrect(d, x, y, w, h, 9, fill=LCD, outline=EDGE, bw=2)
    text(d, "SPORT", x + 8, y + 6, 6.5, (16, 18, 16, 185), BLACK, spacing=1.4)
    for sx, sy in SLOTS['time']:
        draw_char(d, '8', sx, sy, TIME['w'], TIME['h'], TIME['t'], ghost=True, lit=False)
    for yf in (0.3, 0.7):
        cyy = L['time'][1] + TIME['h'] * yf
        d.rectangle([(COLON_X + 1.5) * SS, (cyy - 2.75) * SS, (COLON_X + 7) * SS, (cyy + 2.75) * SS], fill=DARK)
    for sx, sy in SLOTS['sec']:
        draw_char(d, '8', sx, sy, SEC['w'], SEC['h'], SEC['t'], ghost=True, lit=False)

    for key, cx0, cy0, title in L['cards']:
        rrect(d, cx0, cy0, 82, 68, 9, fill=(191, 193, 188, 255), outline=EDGE, bw=2)
        d.rounded_rectangle([(cx0 + 2) * SS, (cy0 + 2) * SS, (cx0 + 80) * SS - 1, (cy0 + 22) * SS], radius=7 * SS, fill=TITLE)
        d.rectangle([(cx0 + 2) * SS, (cy0 + 12) * SS, (cx0 + 80) * SS - 1, (cy0 + 22) * SS], fill=TITLE)
        tw = text_w(title, 11, BOLD, 2)
        text(d, title, cx0 + 41 - tw / 2 + 1, cy0 + 12, 11, LIGHT, BOLD, spacing=2, anchor="lm")
        ix, iy, iw, ih = card_inner(cx0, cy0)
        rrect(d, ix, iy, iw, ih, 4, fill=LCD)
        for sx, sy in SLOTS[key]:
            draw_char(d, '8', sx, sy, CARD['w'], CARD['h'], CARD['t'], ghost=True, lit=False)
    if SLEEP_MODE != 'score':
        d.rectangle([SLEEP_DOT[0] * SS, SLEEP_DOT[1] * SS, (SLEEP_DOT[0] + 4) * SS, (SLEEP_DOT[1] + 4) * SS], fill=DARK)
        text(d, "h", SLEEP_H[0], SLEEP_H[1], 12, DARK, BLACK)
    # battery '%' baked next to the 3 digit slots
    text(d, "%", BAT_PCT[0], BAT_PCT[1], 9, LIGHT, BLACK, anchor="mm")

    for name, (bx, by, bs) in L['btn'].items():
        d.ellipse([bx * SS, by * SS, (bx + bs) * SS, (by + bs) * SS], fill=BTN, outline=EDGE, width=int(1.5 * SS))
        if name == "alipay":
            text(d, "支", bx + bs / 2, by + bs / 2 + 0.5, 19, LIGHT, BLACK, anchor="mm")
        elif name == "alarm":
            icon_clock(d, 20, LIGHT, bx + 10, by + 10)
        elif name == "wechat":
            icon_wechat(d, 20, LIGHT, bx + 10, by + 10)
        elif name == "home":
            icon_home(d, 20, LIGHT, bx + 10, by + 10)

    x, y, w, h = L['temp']
    rrect(d, x, y, w, h, 5, fill=LCD, outline=EDGE, bw=1.5)
    for sx, sy in SLOTS['temp']:
        draw_char(d, '8', sx, sy, TEMP['w'], TEMP['h'], TEMP['t'], ghost=True, lit=False)
    dgx, dgy = DEG
    d.ellipse([dgx * SS, dgy * SS, (dgx + 5) * SS, (dgy + 5) * SS], outline=DARK, width=int(1.5 * SS))
    return img

# ---------- assets ----------
def digit_png(ch, spec):
    img = new(spec['w'], spec['h'])
    d = ImageDraw.Draw(img, "RGBA")
    draw_char(d, ch, 0, 0, spec['w'], spec['h'], spec['t'], ghost=False)
    return down(img, spec['w'], spec['h'])

def text_png(s, px, col, path=BOLD, spacing=0.0, pad=1):
    w = text_w(s, px, path, spacing) + pad * 2
    h = px * 1.35
    img = new(w, h)
    d = ImageDraw.Draw(img, "RGBA")
    text(d, s, pad, h / 2, px, col, path, spacing=spacing, anchor="lm")
    return down(img, w, h)

def ring_png(n):
    S = 50
    img = new(S, S)
    d = ImageDraw.Draw(img, "RGBA")
    cx = cy = S / 2
    for i in range(24):
        lit = i >= 24 - n
        col = (230, 232, 226, 255) if lit else (230, 232, 226, 46)
        a = math.radians(i * 15 - 90)
        r0, r1 = 16.5, 22
        # tick as thin rect rotated
        hw = 1.0
        ca, sa = math.cos(a), math.sin(a)
        pts = []
        for rr, off in ((r0, -hw), (r1, -hw), (r1, hw), (r0, hw)):
            px = cx + ca * rr - sa * off
            py = cy + sa * rr + ca * off
            pts.append((px * SS, py * SS))
        d.polygon(pts, fill=col)
    return down(img, S, S)

def save(img, *p):
    path = os.path.join(OUT, *p)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    return path

def main():
    os.makedirs(OUT, exist_ok=True)
    bg_big = background()
    bg = down(bg_big, W, H).convert("RGBA")
    save(bg, "00_background.png")

    # digit sets
    sets = {"time": TIME, "sec": SEC, "date": DATE, "hr": HR, "card": CARD, "temp": TEMP}
    for name, spec in sets.items():
        for ch in "0123456789":
            save(digit_png(ch, spec), "digits", f"{name}_{ch}.png")
    # battery ring frames and text
    for n in range(25):
        save(ring_png(n), "battery_ring", f"ring_{n:02d}.png")
    for ch in "0123456789%":
        nm = "pct" if ch == "%" else ch
        save(text_png(ch, 11, LIGHT, BLACK), "battery_text", f"bat_{nm}.png")
    # weekday
    for i, wd in enumerate("一二三四五六日", start=1):
        save(text_png("星期" + wd, 15, DARK, BLACK, spacing=0.5), "weekday", f"week_{i}_{wd}.png")
    # weather icons & labels
    icons = [("sunny", "晴"), ("cloudy", "多云"), ("overcast", "阴"), ("rain", "雨"), ("snow", "雪")]
    for kind, lab in icons:
        save(weather_icon(kind, 24), "weather", f"icon_{kind}.png")
        save(text_png(lab, 11, DARK, BOLD, spacing=0.5), "weather", f"label_{kind}_{lab}.png")
    # minus sign for temperature
    ms = new(TEMP['w'], TEMP['h']); md = ImageDraw.Draw(ms)
    draw_char(md, '-', 0, 0, TEMP['w'], TEMP['h'], TEMP['t'], ghost=False)
    save(down(ms, TEMP['w'], TEMP['h']), "digits", "temp_minus.png")

    # sample preview composed from assets
    prev = bg.copy()
    def put(img, x, y):
        prev.alpha_composite(img, (int(round(x)), int(round(y))))
    def put_digits(setname, slots, s):
        for (sx, sy), ch in zip(slots, s):
            im = Image.open(os.path.join(OUT, "digits", f"{setname}_{ch}.png"))
            put(im, sx, sy)
    put_digits("time", SLOTS['time'], "2112")
    put_digits("sec", SLOTS['sec'], "09")
    put_digits("date", [SLOTS['date'][i] for i in (0, 1, 3, 4)], "1114")
    put_digits("hr", SLOTS['hr'], "78")
    put_digits("card", SLOTS['steps'][1:], "2560")
    put_digits("card", SLOTS['cal'][1:], "162")
    put_digits("card", SLOTS['stand'][1:], "8")
    put_digits("card", SLOTS['sleep'], "72")
    put_digits("temp", SLOTS['temp'], "25")
    put(Image.open(os.path.join(OUT, "battery_ring", "ring_19.png")), 19, 25)
    # battery text 80%
    for slot, ch in zip(BAT_SLOTS[1:], "80"):
        cell = new(BAT['w'], BAT['h'])
        cd = ImageDraw.Draw(cell, "RGBA")
        text(cd, ch, BAT['w'] / 2, BAT['h'] / 2 + 0.3, 9.5, LIGHT, BLACK, anchor="mm")
        put(down(cell, BAT['w'], BAT['h']), slot[0], slot[1])
    put(Image.open(os.path.join(OUT, "weekday", "week_6_六.png")), L['weekday'][0] - 1, L['weekday'][1])
    # lunar text as sample
    lun = text_png("十月初五", 11, DARK, BOLD)
    put(lun, L['lunar'][0] - 1, L['lunar'][1])
    put(Image.open(os.path.join(OUT, "weather", "icon_cloudy.png")), 84, 356)
    lab = Image.open(os.path.join(OUT, "weather", "label_cloudy_多云.png"))
    put(lab, 96 - lab.width / 2, 381)
    save(prev, "01_preview_sample_192x490.png")

    # 4x preview with rounded screen on neutral bg for viewing
    big = prev.resize((W * 4, H * 4), Image.LANCZOS)
    mask = Image.new("L", big.size, 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, big.width - 1, big.height - 1], radius=42 * 4, fill=255)
    canvas = Image.new("RGBA", (big.width + 80, big.height + 80), (232, 234, 239, 255))
    canvas.paste(big, (40, 40), mask)
    save(canvas, "02_preview_4x.png")

    # annotated guide
    guide = prev.resize((W * 4, H * 4), Image.LANCZOS).convert("RGBA")
    ov = Image.new("RGBA", guide.size, (0, 0, 0, 0))
    od = ImageDraw.Draw(ov)
    gf = ImageFont.truetype(BOLD, 22, index=2)
    items = layout_items()
    for it in items:
        x, y, w, h = [v * 4 for v in it['box']]
        col = (230, 60, 30, 255) if it['tap'] else (30, 110, 230, 255)
        od.rectangle([x, y, x + w, y + h], outline=col, width=3)
        od.rectangle([x, y, x + 34, y + 26], fill=col)
        od.text((x + 17, y + 13), str(it['id']), font=gf, fill=(255, 255, 255, 255), anchor="mm")
    guide = Image.alpha_composite(guide, ov)
    save(guide, "03_layout_guide_4x.png")

    write_layout(items)

def layout_items():
    items = []
    def add(name, box, data, assets, tap=None):
        items.append(dict(id=len(items) + 1, name=name, box=box, data=data, assets=assets, tap=tap))
    add("电池圆环", (19, 25, 50, 50), "电量 0-100%", "battery_ring/ring_00..24.png(帧 = 四舍五入(电量×24÷100))")
    add("电池数字", (30, 43, 28, 14), "电量数字(居中)", "battery_text/bat_0-9,bat_pct.png 或文本控件 Noto Sans CJK Black 11px #E6E8E2")
    add("心率区(图标+数字)", (14, 76, 66, 28), "心率 bpm(2-3位)", "digits/hr_0-9.png,槽位 x=39/49 y=82", "点击 → 心率测量")
    add("星期", (76, 22, 46, 18), "星期一~日", "weekday/week_1..7.png")
    add("日期 月-日", (76, 43, 72, 23), "MM-DD(中间的'-'已在底图里)", "digits/date_0-9.png,槽位 x=76/91/(跳过)/109/124 y=43")
    add("农历", (76, 70, 48, 16), "农历文字,如 十月初五", "文本控件 Noto Sans CJK Bold 11px #101210")
    add("时间 时:分", (18, 134, 124, 54), "HH:MM(冒号已在底图里)", "digits/time_0-9.png,槽位 x=18/47 和 x=84/113 y=134")
    add("秒", (148, 165, 25, 23), "SS", "digits/sec_0-9.png,槽位 x=148/162 y=165")
    add("步数", (18, 228, 69, 25), "今日步数(最多5位,右对齐/居中均可)", "digits/card_0-9.png,槽位见 layout.csv")
    add("热量", (104, 228, 69, 25), "今日消耗千卡(最多4位)", "digits/card_0-9.png")
    add("站立", (18, 300, 69, 25), "站立次数(最多2位)", "digits/card_0-9.png")
    add("睡眠", (104, 300, 40, 25), "睡眠小时数,如 7.2(小数点和 h 已在底图里)", "digits/card_0-9.png")
    add("天气图标+文字", (66, 354, 60, 44), "天气类型", "weather/icon_*.png + label_*.png")
    add("温度", (66, 410, 60, 32), "温度(2位,度符号已在底图里;负号用 digits/temp_minus.png)", "digits/temp_0-9.png")
    add("支付宝按钮", (12, 356, 40, 40), "—", "已在底图里", "点击 → 支付宝(付款码)")
    add("闹钟按钮", (140, 356, 40, 40), "—", "已在底图里", "点击 → 闹钟")
    add("微信支付按钮", (12, 406, 40, 40), "—", "已在底图里", "点击 → 微信支付")
    add("米家按钮", (140, 406, 40, 40), "—", "已在底图里", "点击 → 米家")
    return items

def write_layout(items):
    with open(os.path.join(OUT, "layout.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["编号", "名称", "x", "y", "宽", "高", "绑定数据", "素材", "点击跳转"])
        for it in items:
            x, y, ww, hh = it['box']
            w.writerow([it['id'], it['name'], x, y, ww, hh, it['data'], it['assets'], it['tap'] or ""])
    # slot coordinates
    with open(os.path.join(OUT, "digit_slots.csv"), "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["区域", "第几位", "x", "y", "素材尺寸"])
        spec = {"time": TIME, "sec": SEC, "date": DATE, "hr": HR, "steps": CARD, "cal": CARD, "stand": CARD, "sleep": CARD, "temp": TEMP}
        nm = {"time": "时间(时十位,时个位,分十位,分个位)", "sec": "秒", "date": "日期(月十,月个,[-],日十,日个)", "hr": "心率",
              "steps": "步数(5位)", "cal": "热量(4位)", "stand": "站立(2位)", "sleep": "睡眠(整数位,小数位)", "temp": "温度"}
        for k, slots in SLOTS.items():
            s = spec[k]
            for i, (x, y) in enumerate(slots, 1):
                w.writerow([nm[k], i, round(x, 1), round(y, 1), f"{int(math.ceil(s['w']))}x{int(math.ceil(s['h']))}"])
    with open(os.path.join(OUT, "layout.json"), "w", encoding="utf-8") as f:
        json.dump(dict(screen=[W, H], items=items, slots={k: [[round(x, 1), round(y, 1)] for x, y in v] for k, v in SLOTS.items()}), f, ensure_ascii=False, indent=1)

if __name__ == "__main__":
    main()
    print("ok")

# 小米手环 9 · 运动 LCD 表盘(自动打包)

在 GitHub 的云端 Windows 服务器上,用开源工具 Mi Create 自带的编译器,把 `face/` 里的工程编译成表盘文件。

## 怎么用(约 5 分钟)
1. 登录 GitHub,右上角 + → New repository,名字随便起,选 Private 也可以。
2. 把这个文件夹里的内容全部上传到仓库根目录。注意隐藏文件夹 `.github` 在网页上拖拽时经常漏掉。
   如果漏了:在仓库页面点 Add file → Create new file,文件名填 `.github/workflows/build.yml`,
   把本包里的 `.github/workflows/build.yml` 内容粘贴进去,提交。
3. 打开仓库的 Actions 标签页 → 左边选 "Build watchface" → Run workflow。如果提示要先启用 Actions,点启用。
4. 等 1-3 分钟,出现绿色对勾后,点进这次运行,最下面 Artifacts 里下载 `SportFace-watchface`。
5. 解压后得到 `SportFace.bin`(和 `SportFace.face` 是同一个文件,只是后缀不同)。
6. 变红叉了就点进去看哪一步报错,把报错文字发给我。

## 安装到手环
- 浏览器工具 miband-hack(https://github.com/ptrinh/miband-hack),支持 `.bin` 表盘(文件头 5A A5),需要电脑版 Chrome 或 Edge。
- 该项目的 README 说明所有设备都还没在真机上测试过,请自己评估风险。

## 表盘里有什么,没有什么
有:电量圆环(0-100% 共 101 帧)、电量数字、星期、月-日、时:分、秒、心率、步数、热量、站立、睡眠分数、温度(含负号)。
点击:心率区 → 心率测量;右上圆形按钮 → 闹钟。

没有或和设计图不同:
- 天气图标和文字:没做,我没有天气类型编号和图标索引的对应表。温度正常显示。
- 农历:手环没有对应的数据源,没做。
- 睡眠:手环数据源里没有"睡眠时长",只有睡眠分数,所以睡眠格显示分数(没有 h)。
- 支付宝、微信支付、米家三个按钮只是装饰,点不了。工具支持的跳转里没有这三个。
- 步数最多 5 位,热量 4 位,站立 2 位。数值为 0 时不显示数字(前导零隐藏)。

## 没验证过的地方
- 数据源编号(时间、心率、步数等)取自 Mi Create 的手环 8 列表,手环 9 的列表它没有收录,我按相同处理,未在手环 9 上确认。
- 点击跳转依赖控件名 `btn_[hrm]`、`btn_[alarm]`,这是我从另一个转换工具的代码里看到的写法,没确认编译器认不认。
- 整个工程我没有在 Mi Create 里打开过,编译器也没跑过。第一次编译失败是有可能的。

## 目录
- `face/SportFace.fprj` 和 `face/images/` — Mi Create 工程和图片
- `assets/` — 全部原始素材和布局标注图
- `tools/` — 生成这些文件的 Python 脚本
- `.github/workflows/build.yml` — 云端打包脚本
